import argparse
from pyspark.sql import SparkSession
from pyspark.sql.functions import current_timestamp, lit
from common.schemas.pagamentos import pagamentos_schema
from common.utils import normalize_columns

# -----------------------------
# Argumentos
# -----------------------------
parser = argparse.ArgumentParser()
parser.add_argument("--execution_date", required=True)
args = parser.parse_args()

# -----------------------------
# Spark Session
# -----------------------------
spark = (
    SparkSession.builder
    .appName("RAW - Pagamentos")
    .enableHiveSupport()
    .getOrCreate()
)

# -----------------------------
# Paths
# -----------------------------
input_path = (
    f"hdfs://namenode:8020/data/landing/ecommerce/"
    f"pagamentos/dt={args.execution_date}"
)

output_base_path = (
    f"hdfs://namenode:8020/data/raw/ecommerce/pagamentos"
)

output_partition_path = (
    f"{output_base_path}/dt={args.execution_date}"
)

print(f"📥 Lendo landing: {input_path}")

# -----------------------------
# Leitura Landing
# -----------------------------
df_landing = spark.read.parquet(input_path)

# -----------------------------
# Padronização de colunas
# -----------------------------
df_landing = normalize_columns(df_landing)

# -----------------------------
# Schema enforcement
# -----------------------------
df_raw = spark.createDataFrame(
    df_landing.rdd,
    schema=pagamentos_schema
)

# -----------------------------
# Metadados técnicos
# -----------------------------
df_raw = (
    df_raw
    .withColumn("ingestion_ts", current_timestamp())
    .withColumn("source_system", lit("ecommerce_mysql"))
    .withColumn("dt", lit(args.execution_date))
)

# -----------------------------
# Deduplicação técnica
# -----------------------------
df_raw = df_raw.dropDuplicates(["id_pagamento"])

print(f"📤 Gravando RAW: {output_partition_path}")

# -----------------------------
# Escrita RAW (Parquet)
# -----------------------------
(
    df_raw.write
    .mode("overwrite")
    .partitionBy("dt")
    .parquet(output_base_path)
)

# -----------------------------
# Spark Warehouse (Tabela externa)
# -----------------------------
spark.sql("CREATE DATABASE IF NOT EXISTS raw_ecommerce")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS raw_ecommerce.pagamentos (
    id_pagamento INT,
    id_pedido INT,
    metodo_pagamento STRING,
    status STRING,
    valor DECIMAL(10,2),
    data_pagamento TIMESTAMP,
    ingestion_ts TIMESTAMP,
    source_system STRING
)
USING PARQUET
PARTITIONED BY (dt)
LOCATION '{output_base_path}'
""")

print("✅ RAW pagamentos processada com sucesso")

spark.stop()
