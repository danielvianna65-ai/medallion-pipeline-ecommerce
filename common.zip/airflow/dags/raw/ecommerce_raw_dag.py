from pendulum import datetime
from airflow import DAG
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator

TABELAS = [
    "pagamentos",
    "pedidos",
    "clientes",
    "produtos",
    "itens_pedido",
    "categorias",
    "estoque",
    "enderecos",
]

with DAG(
    dag_id="raw_ecommerce",
    start_date=datetime(2026, 1, 1, tz="UTC"),
    schedule_interval=None,
    catchup=False,
    max_active_tasks=4,
    tags=["ecommerce", "raw"],
) as dag:

    for tabela in TABELAS:
        SparkSubmitOperator(
            task_id=f"raw_{tabela}",
            application=f"/opt/spark/jobs/raw/raw_{tabela}.py",
            conn_id="spark_standalone",
            deploy_mode="client",
            application_args=["--execution_date", "{{ ds }}"],
            py_files="/tmp/common.zip",
            verbose=True,
        )


